package main;

public class MylibraryVO {

}
